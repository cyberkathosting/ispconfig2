
#undef CCDLFLAGS

#undef LDDLFLAGS

#undef HAVE_SHUT_RD

#undef HAVE_H_ERRNO

#undef HAVE_OPTARG

#undef in_addr_t

#undef HAVE_INADDR_NONE

#undef HAVE_EX__MAX
