#!/bin/sh
. $srcdir/check_common.sh
test_clamd2 3
