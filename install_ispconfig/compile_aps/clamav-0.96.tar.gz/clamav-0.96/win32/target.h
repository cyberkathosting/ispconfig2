#ifndef TARGET_OS_TYPE
#define TARGET_OS_TYPE "win32"
#endif

#ifndef TARGET_ARCH_TYPE
#define TARGET_ARCH_TYPE "i386"
#endif

#ifndef TARGET_CPU_TYPE
#define TARGET_CPU_TYPE "i386"
#endif
